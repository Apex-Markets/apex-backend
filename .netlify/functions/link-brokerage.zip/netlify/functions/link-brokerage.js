    const axios = require('axios');

exports.handler = async (event, context) => {
  if (event.httpMethod !== 'POST') {
    return { statusCode: 405, body: 'Method Not Allowed' };
  }

  const userId = 'user_' + Date.now();
  const CLIENT_ID = 'THE-APEX-INVESTOR-TEST-LCWOQ';
  const CONSUMER_KEY = 'cL3Joma3IF2OygJLOcKvTezOVuVLhMtOPexMkxDrGX0WyZIl3e';
  const BASE_URL = 'https://api.snaptrade.com/api/v1';

  try {
    await axios.post(`${BASE_URL}/snaptrade/registerUser`, { userId }, {
      headers: { clientId: CLIENT_ID, consumerKey: CONSUMER_KEY }
    });

    const { data } = await axios.get(`${BASE_URL}/snaptrade/login`, {
      params: { userId, redirectURI: 'https://theapexinvestor.net/linked' },
      headers: { clientId: CLIENT_ID, consumerKey: CONSUMER_KEY }
    });

    return {
      statusCode: 200,
      body: JSON.stringify({ url: data.url, userId })
    };
  } catch (err) {
    return {
      statusCode: 500,
      body: JSON.stringify({ error: 'Link failed' })
    };
  }
};